Index of every record in this PowerShell cheat sheet!

Records are plain .txt files in the records/ folder, searchable with ./search_records

CORE LANGUAGE
  powershell-version-and-editions.txt
  powershell-help-system.txt
  powershell-arguments-and-parameters.txt
  powershell-variables-and-scoping.txt
  powershell-data-types-and-casting.txt
  powershell-strings-and-string-formatting.txt
  powershell-arrays-and-collections.txt
  powershell-hashtables-and-dictionaries.txt
  powershell-conditional-statements.txt
  powershell-loops.txt
  powershell-switch-statement.txt
  powershell-objects-and-member-access.txt
  powershell-custom-objects-and-select.txt
  powershell-classes-and-enums.txt
  powershell-scriptblocks-closures-and-scope.txt
  powershell-aliases-and-shell-profile.txt

PIPELINES, ERRORS, FUNCTIONS
  powershell-pipeline-fundamentals.txt
  powershell-pipeline-common-parameters.txt
  powershell-error-handling.txt
  powershell-functions.txt
  powershell-modules-and-imports.txt
  powershell-hashing-checksums-and-encoding.txt
  powershell-string-formatting-and-output.txt
  powershell-date-and-time-commands.txt
  powershell-math-random-and-utilities.txt
  powershell-regular-expressions.txt
  powershell-best-practices-and-scripting-conventions.txt

FILES AND DATA
  powershell-file-system-commands.txt
  powershell-reading-and-writing-files.txt
  powershell-csv-files.txt
  powershell-json-files.txt
  powershell-xml-files.txt
  powershell-archive-and-compression.txt
  powershell-registry-operations.txt
  powershell-environment-and-variables.txt

SYSTEM ADMIN
  system-information-and-host-details.txt
  powershell-process-management.txt
  powershell-service-management.txt
  powershell-scheduled-tasks-and-jobs.txt
  powershell-wmi-and-cim.txt
  powershell-active-directory.txt
  powershell-users-and-groups-local.txt
  powershell-event-logs-and-auditing.txt
  powershell-firewall-and-defender.txt
  powershell-disk-and-storage-management.txt
  powershell-performance-and-monitoring.txt
  powershell-logging-and-auditing.txt
  powershell-windows-features-dotnet-and-package-management.txt
  powershell-desktop-and-windows-integration.txt
  powershell-automation-and-gui-scripts.txt

NETWORK AND WEB
  powershell-network-commands.txt
  powershell-tcp-udp-and-port-testing.txt
  powershell-invoke-webrequest-and-rest.txt
  powershell-file-download-and-upload.txt
  powershell-ssh-and-scp.txt

SECURITY AND TESTING
  bypass-powershell-security-policy-and-allow-script-execution.txt
  powershell-script-signing-and-execution-policy.txt
  powershell-credentials-and-secrets.txt
  powershell-encryption-and-hashing-security.txt
  powershell-pester-testing.txt

PLATFORM AND TOOLING
  powershell-remoting-and-sessions.txt
  powershell-powershell-core-vs-windows-powershell.txt
  powershell-scripts-invocation-and-parameters.txt
  powershell-git-and-dev-tools-automation.txt
  powershell-readme-cheatsheet-index.txt
